"use client";

import styled from "styled-components";
import { FaBars, FaSearch, FaBell } from "react-icons/fa";

const variantStyles = {
  modern: { 
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)", 
    color: "#fff" 
  },
  minimal: { 
    background: "#ffffff", 
    color: "#2c3e50",
    border: "1px solid #e1e8ed"
  },
  glassmorphism: { 
    background: "rgba(255, 255, 255, 0.1)", 
    color: "#fff",
    backdrop: "blur(10px)"
  },
};

// ====== VARIANT MODERN: Elevated header with icons ======
const ModernHeader = styled.header`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2.5rem;
  background: ${variantStyles.modern.background};
  color: ${variantStyles.modern.color};
  box-shadow: 0 8px 32px rgba(102, 126, 234, 0.3);
  border-radius: 20px;
  margin-bottom: 1.5rem;
  font-family: "Poppins", sans-serif;
`;

const ModernLogo = styled.div`
  font-size: 1.6rem;
  font-weight: 800;
  letter-spacing: -1px;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  &::before {
    content: "🏨";
    font-size: 2rem;
  }
`;

const ModernNav = styled.nav`
  display: flex;
  gap: 2rem;
  align-items: center;
`;

const ModernLink = styled.a`
  color: inherit;
  text-decoration: none;
  font-weight: 500;
  font-size: 15px;
  position: relative;
  transition: all 0.3s;
  
  &::after {
    content: "";
    position: absolute;
    bottom: -5px;
    left: 0;
    width: 0;
    height: 3px;
    background: white;
    transition: width 0.3s;
  }
  
  &:hover::after {
    width: 100%;
  }
`;

const IconButton = styled.button`
  background: rgba(255, 255, 255, 0.2);
  border: none;
  color: white;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s;
  
  &:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.1);
  }
`;

const IconGroup = styled.div`
  display: flex;
  gap: 0.8rem;
`;

// ====== VARIANT MINIMAL: Clean centered header ======
const MinimalHeader = styled.header`
  background: ${variantStyles.minimal.background};
  color: ${variantStyles.minimal.color};
  border: ${variantStyles.minimal.border};
  padding: 1.5rem 2rem;
  border-radius: 0;
  border-left: none;
  border-right: none;
  margin-bottom: 1.5rem;
  font-family: "Inter", sans-serif;
`;

const MinimalContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const MinimalLogo = styled.div`
  font-size: 1.3rem;
  font-weight: 700;
  color: #2c3e50;
  text-transform: uppercase;
  letter-spacing: 2px;
`;

const MinimalNav = styled.nav`
  display: flex;
  gap: 3rem;
`;

const MinimalLink = styled.a`
  color: #7f8c8d;
  text-decoration: none;
  font-weight: 500;
  font-size: 14px;
  text-transform: uppercase;
  letter-spacing: 1px;
  transition: color 0.3s;
  
  &:hover {
    color: #2c3e50;
  }
`;

const MinimalButton = styled.button`
  background: #2c3e50;
  color: white;
  border: none;
  padding: 0.7rem 1.8rem;
  border-radius: 25px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s;
  font-size: 14px;
  
  &:hover {
    background: #34495e;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(44, 62, 80, 0.3);
  }
`;

// ====== VARIANT GLASSMORPHISM: Glass effect with backdrop blur ======
const GlassHeader = styled.header`
  background: ${variantStyles.glassmorphism.background};
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: ${variantStyles.glassmorphism.color};
  padding: 1.2rem 2rem;
  border-radius: 16px;
  margin-bottom: 1.5rem;
  font-family: "Poppins", sans-serif;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const GlassLogo = styled.div`
  font-size: 1.5rem;
  font-weight: 700;
  background: linear-gradient(135deg, #fff, #a8edea);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`;

const GlassNav = styled.nav`
  display: flex;
  gap: 1.5rem;
  align-items: center;
`;

const GlassLink = styled.a`
  color: rgba(255, 255, 255, 0.9);
  text-decoration: none;
  font-weight: 500;
  padding: 0.5rem 1rem;
  border-radius: 8px;
  transition: all 0.3s;
  
  &:hover {
    background: rgba(255, 255, 255, 0.15);
  }
`;

const GlassSearch = styled.div`
  display: flex;
  align-items: center;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 25px;
  padding: 0.5rem 1.2rem;
  gap: 0.5rem;
  border: 1px solid rgba(255, 255, 255, 0.2);
  
  input {
    background: transparent;
    border: none;
    outline: none;
    color: white;
    font-size: 14px;
    
    &::placeholder {
      color: rgba(255, 255, 255, 0.6);
    }
  }
`;

export default function HeaderVariant({ variant = "modern" }) {
  switch (variant) {
    case "modern":
      return (
        <ModernHeader>
          <ModernLogo>ResortHub</ModernLogo>
          <ModernNav>
            <ModernLink href="#">Home</ModernLink>
            <ModernLink href="#">Rooms</ModernLink>
            <ModernLink href="#">Facilities</ModernLink>
            <ModernLink href="#">Contact</ModernLink>
          </ModernNav>
          <IconGroup>
            <IconButton><FaSearch /></IconButton>
            <IconButton><FaBell /></IconButton>
            <IconButton><FaBars /></IconButton>
          </IconGroup>
        </ModernHeader>
      );
    
    case "minimal":
      return (
        <MinimalHeader>
          <MinimalContainer>
            <MinimalLogo>RESORT</MinimalLogo>
            <MinimalNav>
              <MinimalLink href="#">Home</MinimalLink>
              <MinimalLink href="#">Rooms</MinimalLink>
              <MinimalLink href="#">About</MinimalLink>
              <MinimalLink href="#">Contact</MinimalLink>
            </MinimalNav>
            <MinimalButton>Book Now</MinimalButton>
          </MinimalContainer>
        </MinimalHeader>
      );
    
    case "glassmorphism":
      return (
        <GlassHeader>
          <GlassLogo>✦ Paradise Resort</GlassLogo>
          <GlassNav>
            <GlassLink href="#">Home</GlassLink>
            <GlassLink href="#">Explore</GlassLink>
            <GlassLink href="#">Services</GlassLink>
            <GlassSearch>
              <FaSearch size={14} />
              <input type="text" placeholder="Search..." />
            </GlassSearch>
          </GlassNav>
        </GlassHeader>
      );
    
    default:
      return null;
  }
}

