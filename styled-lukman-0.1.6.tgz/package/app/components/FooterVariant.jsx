"use client";

import styled from "styled-components";
import { 
  FaFacebookF, 
  FaInstagram, 
  FaTwitter, 
  FaLinkedin,
  FaPhone,
  FaEnvelope,
  FaMapMarkerAlt
} from "react-icons/fa";

const variantStyles = {
  stacked: { background: "#2c3e50", color: "#ecf0f1" },
  columns: { background: "linear-gradient(135deg, #434343 0%, #000000 100%)", color: "#fff" },
  centered: { background: "#1a1a2e", color: "#eee" },
};

/* ====== VARIANT STACKED: Vertical sections ====== */
const StackedFooter = styled.footer`
  background: ${variantStyles.stacked.background};
  color: ${variantStyles.stacked.color};
  padding: 3rem 2rem 1.5rem;
  font-family: "Inter", sans-serif;
  border-top: 4px solid #3498db;
`;

const StackedSection = styled.div`
  max-width: 1200px;
  margin: 0 auto 2rem;
  padding-bottom: 2rem;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
`;

const StackedBrand = styled.div`
  margin-bottom: 1.5rem;
  
  h2 {
    font-size: 2rem;
    font-weight: 800;
    margin: 0 0 0.5rem;
    color: #3498db;
  }
  
  p {
    margin: 0;
    opacity: 0.8;
    font-size: 14px;
    max-width: 400px;
  }
`;

const StackedLinks = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 2rem;
  margin: 2rem 0;
`;

const LinkGroup = styled.div`
  h4 {
    font-size: 1rem;
    font-weight: 700;
    margin: 0 0 1rem;
    text-transform: uppercase;
    letter-spacing: 1px;
  }
  
  a {
    display: block;
    color: inherit;
    text-decoration: none;
    margin: 0.6rem 0;
    opacity: 0.8;
    font-size: 14px;
    transition: all 0.3s;
    
    &:hover {
      opacity: 1;
      padding-left: 5px;
      color: #3498db;
    }
  }
`;

const StackedBottom = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 1.5rem;
  font-size: 13px;
  opacity: 0.7;
`;

const SocialIcons = styled.div`
  display: flex;
  gap: 1rem;
  
  a {
    color: inherit;
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.1);
    transition: all 0.3s;
    
    &:hover {
      background: #3498db;
      transform: translateY(-3px);
    }
  }
`;

/* ====== VARIANT COLUMNS: Multi-column layout ====== */
const ColumnsFooter = styled.footer`
  background: ${variantStyles.columns.background};
  color: ${variantStyles.columns.color};
  padding: 4rem 3rem 2rem;
  font-family: "Poppins", sans-serif;
`;

const ColumnsGrid = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr;
  gap: 3rem;
  margin-bottom: 3rem;
`;

const ColumnBox = styled.div`
  h3 {
    font-size: 1.2rem;
    font-weight: 700;
    margin: 0 0 1.5rem;
    position: relative;
    padding-bottom: 0.8rem;
    
    &::after {
      content: "";
      position: absolute;
      bottom: 0;
      left: 0;
      width: 50px;
      height: 3px;
      background: linear-gradient(90deg, #667eea, #764ba2);
    }
  }
  
  p {
    margin: 0.8rem 0;
    opacity: 0.85;
    font-size: 14px;
    line-height: 1.7;
  }
  
  a {
    display: block;
    color: inherit;
    text-decoration: none;
    margin: 0.7rem 0;
    opacity: 0.8;
    font-size: 14px;
    transition: all 0.3s;
    
    &:hover {
      opacity: 1;
      color: #667eea;
      transform: translateX(5px);
    }
  }
`;

const ContactItem = styled.div`
  display: flex;
  align-items: center;
  gap: 0.8rem;
  margin: 1rem 0;
  font-size: 14px;
  
  svg {
    color: #667eea;
    font-size: 16px;
  }
`;

const ColumnsDivider = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  padding-top: 2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 13px;
  opacity: 0.7;
`;

/* ====== VARIANT CENTERED: Center-aligned footer ====== */
const CenteredFooter = styled.footer`
  background: ${variantStyles.centered.background};
  color: ${variantStyles.centered.color};
  padding: 3rem 2rem;
  font-family: "Poppins", sans-serif;
  text-align: center;
`;

const CenteredContent = styled.div`
  max-width: 800px;
  margin: 0 auto;
`;

const CenteredLogo = styled.div`
  font-size: 2.5rem;
  font-weight: 900;
  margin-bottom: 1rem;
  background: linear-gradient(135deg, #667eea, #764ba2);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`;

const CenteredTagline = styled.p`
  font-size: 16px;
  opacity: 0.8;
  margin: 1rem 0 2rem;
  line-height: 1.6;
`;

const CenteredNav = styled.nav`
  display: flex;
  justify-content: center;
  gap: 2rem;
  margin: 2rem 0;
  flex-wrap: wrap;
  
  a {
    color: inherit;
    text-decoration: none;
    font-weight: 500;
    font-size: 15px;
    transition: all 0.3s;
    
    &:hover {
      color: #667eea;
    }
  }
`;

const CenteredSocial = styled.div`
  display: flex;
  justify-content: center;
  gap: 1.5rem;
  margin: 2.5rem 0;
  
  a {
    color: inherit;
    width: 45px;
    height: 45px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    border: 2px solid rgba(255, 255, 255, 0.2);
    transition: all 0.3s;
    font-size: 18px;
    
    &:hover {
      background: linear-gradient(135deg, #667eea, #764ba2);
      border-color: transparent;
      transform: scale(1.1);
    }
  }
`;

const CenteredCopyright = styled.div`
  margin-top: 2rem;
  padding-top: 2rem;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  font-size: 13px;
  opacity: 0.6;
`;

export default function FooterVariant({ variant = "stacked" }) {
  switch (variant) {
    case "stacked":
      return (
        <StackedFooter>
          <StackedSection>
            <StackedBrand>
              <h2>Paradise Resort</h2>
              <p>Rasakan kemewahan dan kenyamanan di jantung surga. Liburan impian Anda menanti.</p>
            </StackedBrand>
            <StackedLinks>
              <LinkGroup>
                <h4>Tautan Cepat</h4>
                <a href="#">Beranda</a>
                <a href="#">Kamar</a>
                <a href="#">Fasilitas</a>
                <a href="#">Galeri</a>
              </LinkGroup>
              <LinkGroup>
                <h4>Layanan</h4>
                <a href="#">Spa & Wellness</a>
                <a href="#">Restoran</a>
                <a href="#">Bar Kolam</a>
                <a href="#">Aktivitas</a>
              </LinkGroup>
              <LinkGroup>
                <h4>Bantuan</h4>
                <a href="#">Hubungi Kami</a>
                <a href="#">FAQ</a>
                <a href="#">Kebijakan Privasi</a>
                <a href="#">Syarat & Ketentuan</a>
              </LinkGroup>
            </StackedLinks>
          </StackedSection>
          <StackedBottom>
            <div>© 2025 Paradise Resort. Hak cipta dilindungi.</div>
            <SocialIcons>
              <a href="#"><FaFacebookF /></a>
              <a href="#"><FaInstagram /></a>
              <a href="#"><FaTwitter /></a>
              <a href="#"><FaLinkedin /></a>
            </SocialIcons>
          </StackedBottom>
        </StackedFooter>
      );
    
    case "columns":
      return (
        <ColumnsFooter>
          <ColumnsGrid>
            <ColumnBox>
              <h3>Tentang Resort</h3>
              <p>
                Resort tepi pantai premium yang menawarkan fasilitas kelas dunia, 
                layanan luar biasa, dan pengalaman tak terlupakan untuk semua tamu.
              </p>
              <ContactItem>
                <FaPhone />
                <span>+62 (555) 123-4567</span>
              </ContactItem>
              <ContactItem>
                <FaEnvelope />
                <span>info@paradiseresort.com</span>
              </ContactItem>
              <ContactItem>
                <FaMapMarkerAlt />
                <span>Jl. Pantai No. 123, Pulau Tropis</span>
              </ContactItem>
            </ColumnBox>
            <ColumnBox>
              <h3>Jelajahi</h3>
              <a href="#">Akomodasi</a>
              <a href="#">Kuliner</a>
              <a href="#">Acara</a>
              <a href="#">Pernikahan</a>
              <a href="#">Penawaran</a>
            </ColumnBox>
            <ColumnBox>
              <h3>Kebijakan</h3>
              <a href="#">Kebijakan Pemesanan</a>
              <a href="#">Pembatalan</a>
              <a href="#">Privasi</a>
              <a href="#">Syarat & Ketentuan</a>
              <a href="#">Peta Situs</a>
            </ColumnBox>
            <ColumnBox>
              <h3>Newsletter</h3>
              <p>Berlangganan untuk penawaran eksklusif dan info terbaru</p>
              <SocialIcons style={{ justifyContent: 'flex-start', marginTop: '1.5rem' }}>
                <a href="#"><FaFacebookF /></a>
                <a href="#"><FaInstagram /></a>
                <a href="#"><FaTwitter /></a>
              </SocialIcons>
            </ColumnBox>
          </ColumnsGrid>
          <ColumnsDivider>
            <div>© 2025 Paradise Resort. Hak Cipta Dilindungi.</div>
            <div>Dirancang dengan ❤️ untuk pengalaman mewah</div>
          </ColumnsDivider>
        </ColumnsFooter>
      );
    
    case "centered":
      return (
        <CenteredFooter>
          <CenteredContent>
            <CenteredLogo>✦ PARADISE ✦</CenteredLogo>
            <CenteredTagline>
              Tempat kemewahan bertemu ketenangan. Temukan pelarian sempurna Anda 
              di destinasi resort kelas dunia kami.
            </CenteredTagline>
            <CenteredNav>
              <a href="#">Beranda</a>
              <a href="#">Kamar</a>
              <a href="#">Kuliner</a>
              <a href="#">Spa</a>
              <a href="#">Acara</a>
              <a href="#">Kontak</a>
            </CenteredNav>
            <CenteredSocial>
              <a href="#"><FaFacebookF /></a>
              <a href="#"><FaInstagram /></a>
              <a href="#"><FaTwitter /></a>
              <a href="#"><FaLinkedin /></a>
            </CenteredSocial>
            <CenteredCopyright>
              © 2025 Paradise Resort. Hak cipta dilindungi. | Kebijakan Privasi | Syarat Penggunaan
            </CenteredCopyright>
          </CenteredContent>
        </CenteredFooter>
      );
    
    default:
      return null;
  }
}
