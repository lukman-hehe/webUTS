"use client";

import { useState } from "react";
import styled from "styled-components";
import {
  FaHome,
  FaBed,
  FaArrowRight,
  FaInfoCircle,
  FaBars,
  FaCopy,
  FaCheck,
} from "react-icons/fa";
import HeaderVariant from "./components/HeaderVariant";
import CardVariant from "./components/CardVariant";
import ButtonVariant from "./components/ButtonVariant";
import FooterVariant from "./components/FooterVariant";
import SidebarVariant from "./components/SidebarVariant";

// HEADER UTAMA (bukan komponen variant)
const MainHeader = styled.header`
  width: 100%;
  background: #d4d4d4;
  color: #222;
  text-align: center;
  padding: 1rem 0;
  font-size: 1.5rem;
  font-weight: 700;
  letter-spacing: 1px;
  border-radius: 8px;
  margin-bottom: 1.5rem;
`;

// FOOTER UTAMA (bukan komponen variant)
const MainFooter = styled.footer`
  width: 100%;
  background: #d4d4d4;
  color: #222;
  text-align: center;
  padding: 1rem 0;
  font-size: 1.2rem;
  font-weight: 700;
  letter-spacing: 1px;
  border-radius: 8px;
  margin-top: 2rem;
`;

const Container = styled.div`
  display: flex;
  min-height: 100vh;
  font-family: "Poppins", sans-serif;
  background: #f5f5f5;
`;

// Sidebar Navigation
const Sidebar = styled.aside`
  position: fixed;
  top: 0;                  // Sidebar mulai dari paling atas halaman
  left: 0;
  width: 280px;
  height: 100vh;           // Tinggi 100% viewport, tidak dipotong header/footer
  background: #1a1a1a;
  color: white;
  display: flex;
  flex-direction: column;
  padding-top: 2rem;       // Bisa disesuaikan, kalau ingin lebih rapat ke atas pakai 1rem atau 0
  padding-bottom: 1rem;
  z-index: 10;
`;


const SidebarTitle = styled.h2`
  font-size: 1.2rem;
  font-weight: 700;
  text-align: left;
  margin: 0 0 2rem 2rem;
  letter-spacing: 1px;
`;

const ComponentsLabel = styled.div`
  margin: 1rem 2rem;
  font-size: 1rem;
  font-weight: 600;
  color: #e0e0e0;
  letter-spacing: 1px;
`;

const MenuItem = styled.button`
  display: flex;
  align-items: center;
  gap: 1rem;
  margin: 0.5rem 2rem;
  padding: 0.5rem 1rem;
  background: ${({ $active }) => ($active ? "#333" : "#232323")};
  border: none;
  border-radius: 8px;
  color: white;
  font-size: 0.9rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s;
  width: calc(100% - 4rem);
  text-align: left;

  svg {
    font-size: 1rem;
  }

  &:hover {
    background: #444;
  }
`;

// Main Content Area
const MainContent = styled.main`
  flex: 1;
  margin-left: 280px;
  padding: 2rem;
`;

const ContentHeader = styled.div`
  margin-bottom: 2rem;

  h1 {
    font-size: 1.2rem;
    font-weight: 700;
    margin: 0 0 1rem;
    color: #222;
  }

  p {
    margin: 0;
    color: #666;
    font-size: 0.95rem;
  }
`;

const VariantSection = styled.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
`;

const SectionTitle = styled.h3`
  font-size: 1.1rem;
  font-weight: 600;
  margin: 0 0 2rem;
  color: #1a1a1a;
  padding-bottom: 0.8rem;
  border-bottom: 2px solid #f0f0f0;
`;

const VariantCard = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  padding: 1.5rem;
  background: #f9f9f9ff;
  border-radius: 12px;
  border: 2px solid #e0e0e0;
  margin-bottom: 1.5rem;
`;

const VariantLabel = styled.div`
  font-size: 0.9rem;
  font-weight: 600;
  color: #666;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-bottom: 1rem;
`;

const CodeSection = styled.div`
  margin-top: 1.5rem;
`;

const CodeHeader = styled.div`
  font-size: 0.85rem;
  font-weight: 600;
  color: #333;
  margin-bottom: 0.5rem;
`;

const CodeBlock = styled.div`
  background: #1e1e1e;
  border-radius: 8px;
  padding: 1.2rem;
  position: relative;
  overflow-x: auto;
`;

const CodeContent = styled.pre`
  margin: 0;
  font-family: "Courier New", Courier, monospace;
  font-size: 14px;
  line-height: 1.6;
  color: #d4d4d4;

  .keyword {
    color: #569cd6;
  }
  .string {
    color: #ce9178;
  }
  .tag {
    color: #4ec9b0;
  }
  .attr {
    color: #9cdcfe;
  }
`;

const CopyButton = styled.button`
  position: absolute;
  top: 1rem;
  right: 1rem;
  background: ${({ $copied }) => ($copied ? "#10b981" : "#3b82f6")};
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.4rem;
  transition: all 0.3s;

  &:hover {
    background: ${({ $copied }) => ($copied ? "#059669" : "#2563eb")};
  }

  svg {
    font-size: 14px;
  }
`;

const VariantGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 2rem;
  margin-top: 2rem;
`;

const SidebarGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  margin-top: 2rem;
`;

const SidebarPreview = styled.div`
  height: 500px;
  overflow: hidden;
  border-radius: 12px;
  border: 2px solid #e0e0e0;
  background: #f9f9f9;
`;

export default function Page() {
  const [activeMenu, setActiveMenu] = useState("header");
  const [copiedStates, setCopiedStates] = useState({});

  const menuItems = [
    { id: "button", label: "Button", icon: <FaArrowRight /> },
    { id: "card", label: "Card", icon: <FaBed /> },
    { id: "header", label: "Header", icon: <FaHome /> },
    { id: "footer", label: "Footer", icon: <FaInfoCircle /> },
    { id: "sidebar", label: "SideBar", icon: <FaBars /> },
  ];

  const copyToClipboard = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedStates({ ...copiedStates, [id]: true });
    setTimeout(() => {
      setCopiedStates({ ...copiedStates, [id]: false });
    }, 2000);
  };

  const CodeSnippet = ({ code, id }) => {
    const isCopied = copiedStates[id];

    return (
      <CodeSection>
        <CodeHeader>Cara Menggunakan:</CodeHeader>
        <CodeBlock>
          <CopyButton
            $copied={isCopied}
            onClick={() => copyToClipboard(code, id)}
          >
            {isCopied ? (
              <>
                <FaCheck /> Copied
              </>
            ) : (
              <>
                <FaCopy /> Copy
              </>
            )}
          </CopyButton>
          <CodeContent>
            <code dangerouslySetInnerHTML={{ __html: code }} />
          </CodeContent>
        </CodeBlock>
      </CodeSection>
    );
  };

  const renderContent = () => {
    switch (activeMenu) {
      case "header":
        return (
          <VariantSection>
            <SectionTitle>Header Component - 3 Variants</SectionTitle>

            <VariantCard>
              <VariantLabel>Modern</VariantLabel>
              <HeaderVariant variant="modern" />
              <CodeSnippet
                id="header-modern"
                code={`<span class="tag">&lt;HeaderVariant</span> <span class="attr">variant</span>=<span class="string">"modern"</span> <span class="tag">/&gt;</span>`}
              />
            </VariantCard>

            <VariantCard>
              <VariantLabel>Minimal</VariantLabel>
              <HeaderVariant variant="minimal" />
              <CodeSnippet
                id="header-minimal"
                code={`<span class="tag">&lt;HeaderVariant</span> <span class="attr">variant</span>=<span class="string">"minimal"</span> <span class="tag">/&gt;</span>`}
              />
            </VariantCard>

            <VariantCard>
              <VariantLabel>Glassmorphism</VariantLabel>
              <div style={{ background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)", padding: "2rem", borderRadius: "12px" }}>
                <HeaderVariant variant="glassmorphism" />
              </div>
              <CodeSnippet
                id="header-glass"
                code={`<span class="tag">&lt;HeaderVariant</span> <span class="attr">variant</span>=<span class="string">"glassmorphism"</span> <span class="tag">/&gt;</span>`}
              />
            </VariantCard>
          </VariantSection>
        );

      case "card":
        return (
          <VariantSection>
            <SectionTitle>Card Component - 3 Variants</SectionTitle>
            <VariantGrid>

              <div>
                <VariantLabel>Elevated</VariantLabel>
                <CardVariant variant="elevated" />
                <CodeSnippet
                  id="card-elevated"
                  code={`<span class="tag">&lt;CardVariant</span> <span class="attr">variant</span>=<span class="string">"elevated"</span> <span class="tag">/&gt;</span>`}
                />
              </div>

              <div>
                <VariantLabel>Bordered</VariantLabel>
                <CardVariant variant="bordered" />
                <CodeSnippet
                  id="card-bordered"
                  code={`<span class="tag">&lt;CardVariant</span> <span class="attr">variant</span>=<span class="string">"bordered"</span> <span class="tag">/&gt;</span>`}
                />
              </div>

              <div>
                <VariantLabel>Gradient</VariantLabel>
                <CardVariant variant="gradient" />
                <CodeSnippet
                  id="card-gradient"
                  code={`<span class="tag">&lt;CardVariant</span> <span class="attr">variant</span>=<span class="string">"gradient"</span> <span class="tag">/&gt;</span>`}
                />
              </div>
            </VariantGrid>
          </VariantSection>
        );

      case "button":
        return (
          <VariantSection>
            <SectionTitle>Button Component - 3 Variants</SectionTitle>
            

            <VariantCard>
              <VariantLabel>Solid</VariantLabel>
              <ButtonVariant variant="solid" onClick={() => alert("Solid Button clicked!")} />
              <CodeSnippet
                id="button-solid"
                code={`<span class="tag">&lt;ButtonVariant</span> <span class="attr">variant</span>=<span class="string">"solid"</span> <span class="attr">onClick</span>={<span class="keyword">()</span> <span class="keyword">=&gt;</span> <span class="keyword">alert</span>(<span class="string">'Clicked!'</span>)} <span class="tag">/&gt;</span>`}
              />
            </VariantCard>
            <VariantCard>
              <VariantLabel>Outline</VariantLabel>
              <ButtonVariant variant="outline" onClick={() => alert("Outline Button clicked!")} />
              <CodeSnippet
                id="button-outline"
                code={`<span class="tag">&lt;ButtonVariant</span> <span class="attr">variant</span>=<span class="string">"outline"</span> <span class="attr">onClick</span>={<span class="keyword">()</span> <span class="keyword">=&gt;</span> <span class="keyword">alert</span>(<span class="string">'Clicked!'</span>)} <span class="tag">/&gt;</span>`}
              />
            </VariantCard>
            <VariantCard>
              <VariantLabel>Pill</VariantLabel>
              <ButtonVariant variant="pill" onClick={() => alert("Pill Button clicked!")} />
              <CodeSnippet
                id="button-pill"
                code={`<span class="tag">&lt;ButtonVariant</span> <span class="attr">variant</span>=<span class="string">"pill"</span> <span class="attr">onClick</span>={<span class="keyword">()</span> <span class="keyword">=&gt;</span> <span class="keyword">alert</span>(<span class="string">'Clicked!'</span>)} <span class="tag">/&gt;</span>`}
              />
            </VariantCard>
          </VariantSection>
        );

      case "footer":
        return (
          <VariantSection>
            <SectionTitle>Footer Component - 3 Variants</SectionTitle>
            <VariantCard>
              <VariantLabel>Stacked</VariantLabel>
              <FooterVariant variant="stacked" />
              <CodeSnippet
                id="footer-stacked"
                code={`<span class="tag">&lt;FooterVariant</span> <span class="attr">variant</span>=<span class="string">"stacked"</span> <span class="tag">/&gt;</span>`}
              />
            </VariantCard>
            <VariantCard>
              <VariantLabel>Columns</VariantLabel>
              <FooterVariant variant="columns" />
              <CodeSnippet
                id="footer-columns"
                code={`<span class="tag">&lt;FooterVariant</span> <span class="attr">variant</span>=<span class="string">"columns"</span> <span class="tag">/&gt;</span>`}
              />
            </VariantCard>
            <VariantCard>
              <VariantLabel>Centered</VariantLabel>
              <FooterVariant variant="centered" />
              <CodeSnippet
                id="footer-centered"
                code={`<span class="tag">&lt;FooterVariant</span> <span class="attr">variant</span>=<span class="string">"Stacked"</span> <span class="tag">/&gt;</span>`}
              />
            </VariantCard>
          </VariantSection>
        );

      case "sidebar":
        return (
          <VariantSection>
            <SectionTitle>Sidebar Component - 3 Variants</SectionTitle>
            <SidebarGrid>
              <div>
                <SidebarPreview>
                  <VariantLabel>Compact</VariantLabel>
                  <SidebarVariant variant="compact" onSelect={(item) => console.log(item)} />
                </SidebarPreview>
                <CodeSnippet
                  id="sidebar-compact"
                  code={`<span class="tag">&lt;SidebarVariant</span> <span class="attr">variant</span>=<span class="string">"compact"</span> <span class="attr">onSelect</span>={<span class="keyword">(item)</span> <span class="keyword">=&gt;</span> <span class="keyword">console.log</span>(item)} <span class="tag">/&gt;</span>`}
                />
              </div>
              <div>
                <SidebarPreview>
                  <VariantLabel>Expanded</VariantLabel>
                  <SidebarVariant variant="expanded" onSelect={(item) => console.log(item)} />
                </SidebarPreview>
                <CodeSnippet
                  id="sidebar-expanded"
                  code={`<span class="tag">&lt;SidebarVariant</span> <span class="attr">variant</span>=<span class="string">"expanded"</span> <span class="attr">onSelect</span>={<span class="keyword">(item)</span> <span class="keyword">=&gt;</span> <span class="keyword">console.log</span>(item)} <span class="tag">/&gt;</span>`}
                />
              </div>
              <div>
                <SidebarPreview>
                  <VariantLabel>Floating</VariantLabel>
                  <SidebarVariant variant="floating" onSelect={(item) => console.log(item)} />
                </SidebarPreview>
                <CodeSnippet
                  id="sidebar-floating"
                  code={`<span class="tag">&lt;SidebarVariant</span> <span class="attr">variant</span>=<span class="string">"floating"</span> <span class="attr">onSelect</span>={<span class="keyword">(item)</span> <span class="keyword">=&gt;</span> <span class="keyword">console.log</span>(item)} <span class="tag">/&gt;</span>`}
                />
              </div>
            </SidebarGrid>
          </VariantSection>
        );

      default:
        return null;
    }
  };

  return (
    <>
      <MainHeader>HEADER</MainHeader>
      <Container>
        <Sidebar>
          <SidebarTitle>SIDEBAR</SidebarTitle>
          <ComponentsLabel>Components</ComponentsLabel>
          {menuItems.map((item) => (
            <MenuItem
              key={item.id}
              $active={activeMenu === item.id}
              onClick={() => setActiveMenu(item.id)}
            >
              {item.icon}
              <span>{item.label}</span>
            </MenuItem>
          ))}
        </Sidebar>

        <MainContent>
          <ContentHeader>
            <h1>
              Tampilan Variant Component
            </h1>
          </ContentHeader>
          {renderContent()}
        </MainContent>
      </Container>
      <MainFooter>FOOTER</MainFooter>
    </>
  );
}



